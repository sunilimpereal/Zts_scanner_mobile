package com.example.zts_counter_desktop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
