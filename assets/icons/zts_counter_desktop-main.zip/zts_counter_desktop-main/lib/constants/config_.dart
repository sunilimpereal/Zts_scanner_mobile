class Config
{
   String API_ROOT = 'http://zts.afroaves.com:8080/api/v1/';
   String ICON_ROOT = 'https://zts.afroaves.com/icons/';
}