// ignore: file_names
class AppFonts{
  String ubuntu = 'ubuntu';
  String notoSans = 'Noto Sans';
  String varelaRound = 'VarelaRound';
}